
const addButton = document.getElementById('addButton')
const taskInput = document.getElementById('taskInput')
const taskList = document.getElementById('taskList')

addButton.onclick = function() {
     
    if (taskInput.value === "") {
        alert('Nazwa zadania musi być wpisana")')
    } else {
        const li = document.createElement('li');
        li.className = 'task-item';
        
        const span = document.createElement('span');
        span.className = 'task-name';
        span.textContent = taskInput.value;

        const editButton = document.createElement('button');
        editButton.textContent = 'Edytuj';
        editButton.onclick = function() {
            if (editButton.textContent === 'Edytuj') {
                const input = document.createElement('input');
                input.type = 'text';
                input.value = span.textContent;

                li.insertBefore(input, span);
                li.removeChild(span);

                editButton.textContent = 'Zatwierdź zmiany';
            } else {
                const input = li.querySelector('input');

                if (input.value === "") {
                    alert('Nazwa zadnia musi zostać wpisana')
                } else {
                    span.textContent = input.value;
                    li.insertBefore(span, input);
                    li.removeChild(input);
                    editButton.textContent = 'Edytuj';
                }
            }
        };

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Usuń';
        deleteButton.onclick = function() {
            taskList.removeChild(li);
        };

        li.appendChild(span);
        li.appendChild(editButton);
        li.appendChild(deleteButton);
        taskList.appendChild(li);

        taskInput.value = "";
    }
}